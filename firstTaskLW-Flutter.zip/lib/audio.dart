import 'package:flutter/material.dart';
import 'package:flutter_statusbarcolor/flutter_statusbarcolor.dart';
import 'package:chewie_audio/chewie_audio.dart';
import 'package:video_player/video_player.dart';
import 'package:fluttertoast/fluttertoast.dart';

// ignore: camel_case_types
class audioPlay extends StatelessWidget {
  Widget build(BuildContext context) {
    toast() {
      Fluttertoast.showToast(
          msg: " Enjoy Musics !!",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.black,
          textColor: Colors.white,
          fontSize: 23);
    }

// ignore: unused_local_variable
    var back = Icon(
      Icons.arrow_back,
      color: Colors.purpleAccent,
    );

    // ignore: unused_local_variable
    var myLeadingButtonAudio = IconButton(
        icon: back,
        onPressed: () {
          Navigator.pop(context);
        });

    var music = Icon(
      Icons.music_note,
      color: Colors.white,
    );

    var musicbutton = IconButton(icon: music, onPressed: toast);

    FlutterStatusbarcolor.setStatusBarColor(Colors.yellowAccent.shade100);

    var myAppBarMusic = AppBar(
      backgroundColor: Colors.black87,
      title: Text('Enjoy Musics 😎😍'),
      leading: myLeadingButtonAudio,
      actions: <Widget>[
        musicbutton,
      ],
    );

    var vc = VideoPlayerController.network(
        'https://github.com/ranjitben10/musics/raw/master/Maroon-5-Memories.mp3');

    var audio = ChewieAudioController(
      videoPlayerController: vc,
      autoPlay: false,
      looping: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: Colors.black,
        handleColor: Colors.purple,
        backgroundColor: Colors.yellowAccent.shade100,
        bufferedColor: Colors.lightGreen,
      ),
      autoInitialize: true,
    );

    var vc1 = VideoPlayerController.network(
        'https://github.com/ranjitben10/musics/raw/master/Maroon-5-Girls-Like-You-ft.-Cardi-B.mp3');

    var audio1 = ChewieAudioController(
      videoPlayerController: vc1,
      autoPlay: false,
      looping: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: Colors.black,
        handleColor: Colors.purple,
        backgroundColor: Colors.yellowAccent.shade100,
        bufferedColor: Colors.lightGreen,
      ),
      autoInitialize: true,
    );

    var vc2 = VideoPlayerController.network(
        'https://github.com/ranjitben10/musics/raw/master/KGF%20CHAPTER%202%20-%20Official%20Trailer%20Rocking%20Star%20Yash%20Sanjay%20Dutt%20Prashanth%20Neel%20KGF%202.mp3');

    var audio2 = ChewieAudioController(
      videoPlayerController: vc2,
      autoPlay: false,
      looping: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: Colors.black,
        handleColor: Colors.purple,
        backgroundColor: Colors.yellowAccent.shade100,
        bufferedColor: Colors.lightGreen,
      ),
      autoInitialize: true,
    );
    var vc3 = VideoPlayerController.network(
        'https://github.com/ranjitben10/musics/raw/master/Tayla%20Parx%20-%20Fight%20-%20THE%20EYE%20(online-audio-converter.com).mp3');

    var audio3 = ChewieAudioController(
      videoPlayerController: vc3,
      autoPlay: false,
      looping: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: Colors.black,
        handleColor: Colors.purple,
        backgroundColor: Colors.yellowAccent.shade100,
        bufferedColor: Colors.lightGreen,
      ),
      autoInitialize: true,
    );
    var vc4 = VideoPlayerController.network(
        'https://github.com/ranjitben10/musics/raw/master/the-rock-7305.mp3');

    var audio4 = ChewieAudioController(
      videoPlayerController: vc4,
      autoPlay: false,
      looping: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: Colors.black,
        handleColor: Colors.purple,
        backgroundColor: Colors.yellowAccent.shade100,
        bufferedColor: Colors.lightGreen,
      ),
      autoInitialize: true,
    );
    var vc5 = VideoPlayerController.network(
        'https://github.com/ranjitben10/musics/raw/master/Tum-Hi-Aana-b-Marjaavaan-(pagalworldsongs.co.in).mp3');

    var audio5 = ChewieAudioController(
      videoPlayerController: vc5,
      autoPlay: false,
      looping: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: Colors.black,
        handleColor: Colors.purple,
        backgroundColor: Colors.yellowAccent.shade100,
        bufferedColor: Colors.lightGreen,
      ),
      autoInitialize: true,
    );
    var myAudioBody = Container(
        //margin: EdgeInsets.only(top: 90),
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: NetworkImage(
                'https://images.pexels.com/photos/1337753/pexels-photo-1337753.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            children: <Widget>[
              
              Container(
                margin: EdgeInsets.all(30),
                padding: EdgeInsets.all(10),
                height: 50,
                child: ChewieAudio(
                  controller: audio,
                ),
              ),
              Container(
                margin: EdgeInsets.all(20),
                padding: EdgeInsets.all(10),
                height: 50,
                child: ChewieAudio(
                  controller: audio1,
                ),
              ),
              Container(
                margin: EdgeInsets.all(30),
                padding: EdgeInsets.all(10),
                height: 50,
                child: ChewieAudio(
                  controller: audio2,
                ),
              ),
              Container(
                margin: EdgeInsets.all(30),
                padding: EdgeInsets.all(10),
                height: 50,
                child: ChewieAudio(
                  controller: audio3,
                ),
              ),
              Container(
                margin: EdgeInsets.all(30),
                padding: EdgeInsets.all(10),
                height: 50,
                child: ChewieAudio(
                  controller: audio4,
                ),
              ),
              Container(
                margin: EdgeInsets.all(30),
                padding: EdgeInsets.all(10),
                height: 50,
                child: ChewieAudio(
                  controller: audio5,
                ),
              ),
            ],
          ),
        ));

    var home = Scaffold(
      appBar: myAppBarMusic,
      body: myAudioBody,
    );

    var musicPage = MaterialApp(
      home: home,
      debugShowCheckedModeBanner: false,
    );
    return musicPage;
  }
}
