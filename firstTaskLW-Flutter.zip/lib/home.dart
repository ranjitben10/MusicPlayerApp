import 'audio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_statusbarcolor/flutter_statusbarcolor.dart';

// ignore: camel_case_types
class audioApp extends StatelessWidget {
  Widget build(BuildContext context) {
    FlutterStatusbarcolor.setStatusBarColor(Colors.black);

    var myLeadingIconHome = Icon(
      Icons.audiotrack,
      color: Colors.green,
    );

    var headset = Icon(
      Icons.headset_mic,
      color: Colors.white,
    );

    var appBarHome = AppBar(
      backgroundColor: Colors.black,
      title: Text('MusicPlayer 😎'),
      leading: myLeadingIconHome,
      actions: <Widget>[
        headset,
      ],
    );

    var homeBody = Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: NetworkImage(
                'https://images.pexels.com/photos/1337753/pexels-photo-1337753.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500'),
            //fit: BoxFit.cover,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 115,
              height: 55,
              margin: EdgeInsets.only(top: 160),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6.0),
                  border: Border.all(
                      width: 1, color: Colors.transparent.withGreen(100))),
              child: RaisedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) {
                        return audioPlay();
                      }),
                    );
                  },
                  color: Colors.pinkAccent,
                  padding: EdgeInsets.all(10),
                  child: Text(
                    'PlayAudio',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  )),
            ),
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  
                  Text('😎'),
                                 
                ],
              ),
            )
          ],
        ));

    var home = Scaffold(
      appBar: appBarHome,
      body: homeBody,
    );

    var homePage = MaterialApp(
      home: home,
      debugShowCheckedModeBanner: false,
    );
    return homePage;
  }
}
